package com.cmpe277.hackathon.mainactivity.interfaces;

import com.cmpe277.hackathon.mainactivity.models.UserType;

public interface IDateHelper {
    UserType fetchUserType();
}
